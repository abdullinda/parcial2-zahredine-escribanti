import React from "react";

const Label =() => {
    return(
        <div>
            Soy un label
        </div>
    )
};

export default Label;